# Entrelampistas

Publicación editorial independiente. Neo Grotesque SC. Klein + Rojo + Papel.
Sharp, clean, elegant, contemporary, open, casual and simple.

---

## Skills — leer antes de cualquier tarea

| Tarea | Leer |
|-------|------|
| Cualquier cosa visual | `.claude/skills/entrelampistas-design-system/SKILL.md` |
| Cualquier cosa de texto o copy | `.claude/skills/editor-lampista/SKILL.md` |
| Contexto completo del proyecto | `.claude/prompts/00-vision.md` |
| Rediseño web | `.claude/prompts/rediseno-web.md` |
| Ilustraciones SVG | `.claude/prompts/ilustraciones.md` |
| Contenido y ensayos | `.claude/prompts/contenido-web.md` |
| Instagram | `.claude/prompts/instagram.md` |
| Newsletter | `.claude/prompts/newsletter.md` |
| OG images | `.claude/prompts/og-images.md` |
| Lanzamiento al mercado | `.claude/prompts/lanzamiento.md` |

---

## Antes de escribir código

1. Lee `styles/tokens.css` — variables CSS. Usa SOLO estas. No hex sueltos.
2. Lee `styles/components.css` — componentes con craft aplicado.
3. Nuevo componente → mira `src/components/seed-components.html` primero.

## Antes de escribir texto o copy

Lee `.claude/skills/editor-lampista/SKILL.md` — identidad, tono, Clara, territorios.

---

## Reglas (romper cualquiera es un error)

- **Tipografía:** solo Neo Grotesque SC. Sin serif. Sin italic. Nunca.
- **Colores:** solo variables CSS. `color: blue` es un error. `color: var(--klein-vibrant)` es correcto.
- **Transiciones:** solo variables de timing/easing. `transition: all 0.3s ease` es un error.
- **Hover states:** todos deben tener transition. Un cambio brusco es un error.
- **Botones:** `:active` siempre tiene `transform: scale(0.98)`.
- **Cards:** hover lift máximo `translateY(-2px)`.
- **Links:** underline cambia de COLOR en hover. Nunca desaparece.
- **Animación:** nunca animes width, height, margin, padding, top, left.

---

## Estructura de archivos

```
styles/tokens.css           ← Variables (colores, spacing, timing, easing)
styles/base.css             ← Reset, tipografía, accesibilidad, responsive
styles/components.css       ← Componentes con craft aplicado
styles/main.css             ← CSS actual de la landing
src/components/             ← HTML semilla de referencia
src/pages/                  ← Páginas
src/content/                ← Ensayos en Markdown
src/content/mapa-de-ideas.md ← El jardín de ideas — actualizar con cada ensayo
public/fonts/               ← Neo Grotesque SC
public/og/                  ← OG images generadas
.claude/skills/             ← Skills del proyecto
.claude/prompts/            ← Briefs operativos por misión
```

---

## Verificación visual

Después de cada cambio visual:
```bash
node screenshot.mjs http://localhost:3000
```
Verificar: colores son variables · transiciones usan --duration-* · hover states suaves · símbolo visible en nav

---

## Accesibilidad (obligatorio)

- `:focus-visible` en todos los interactivos
- `@media (prefers-reduced-motion)` en animaciones
- HTML semántico: `<article>`, `<nav>`, `<main>`, `<section aria-label="">`, `<header>`, `<footer>`
- Alt text en imágenes · aria-hidden en ilustraciones decorativas
